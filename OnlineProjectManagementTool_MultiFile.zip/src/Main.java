import java.util.*;

public class Main {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        List<User> users = new ArrayList<>();
        List<Project> projects = new ArrayList<>();

        AdminDashboard admin = new AdminDashboard(sc,users,projects);
        PMDashboard pm = new PMDashboard(sc,projects);
        TeamDashboard team = new TeamDashboard(sc,projects);

        while(true){
            System.out.println("\n==== ONLINE PROJECT MANAGEMENT TOOL ====");
            System.out.println("1. Admin");
            System.out.println("2. Project Manager");
            System.out.println("3. Team Member");
            System.out.println("4. Exit");
            int c=sc.nextInt(); sc.nextLine();

            if(c==1) admin.menu();
            else if(c==2) pm.menu();
            else if(c==3) team.menu();
            else return;
        }
    }
}
