public class Task {
    public int id;
    public String title;
    public String status;
    public String assignee;

    public Task(int id,String title,String status,String assignee){
        this.id=id; this.title=title; this.status=status; this.assignee=assignee;
    }

    public String toString(){
        return "Task ID:"+id+", Title:"+title+", Status:"+status+", Assigned:"+assignee;
    }
}
