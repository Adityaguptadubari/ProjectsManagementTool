import java.util.*;

public class PMDashboard {
    Scanner sc;
    List<Project> projects;

    public PMDashboard(Scanner sc,List<Project> projects){
        this.sc=sc; this.projects=projects;
    }

    public void menu(){
        while(true){
            System.out.println("\n--- Project Manager Dashboard ---");
            System.out.println("1. Create Project");
            System.out.println("2. Assign Task");
            System.out.println("3. Monitor Progress");
            System.out.println("4. Back");
            int c=sc.nextInt(); sc.nextLine();
            if(c==1) createProject();
            else if(c==2) assignTask();
            else if(c==3) monitor();
            else return;
        }
    }

    void createProject(){
        System.out.print("Project ID: "); int id=sc.nextInt(); sc.nextLine();
        System.out.print("Title: "); String title=sc.nextLine();
        System.out.print("Description: "); String desc=sc.nextLine();
        System.out.print("Timeline: "); String timeline=sc.nextLine();
        projects.add(new Project(id,title,desc,timeline));
        System.out.println("Project created!");
    }

    void assignTask(){
        System.out.print("Project ID: "); int pid=sc.nextInt(); sc.nextLine();
        Project p = projects.stream().filter(x->x.id==pid).findFirst().orElse(null);
        if(p==null){ System.out.println("Project not found."); return; }

        System.out.print("Task ID: "); int tid=sc.nextInt(); sc.nextLine();
        System.out.print("Task Title: "); String title=sc.nextLine();
        System.out.print("Assign to (Name): "); String assign=sc.nextLine();

        p.tasks.add(new Task(tid,title,"TODO",assign));
        System.out.println("Task assigned!");
    }

    void monitor(){
        for(Project p:projects){
            System.out.println(p);
            for(Task t:p.tasks) System.out.println("  "+t);
        }
    }
}
