import java.util.*;

public class TeamDashboard {
    Scanner sc;
    List<Project> projects;

    public TeamDashboard(Scanner sc,List<Project> projects){
        this.sc=sc; this.projects=projects;
    }

    public void menu(){
        System.out.print("Enter your name: ");
        String name=sc.nextLine();

        while(true){
            System.out.println("\n--- Team Member Dashboard ---");
            System.out.println("1. View My Tasks");
            System.out.println("2. Update Task Status");
            System.out.println("3. View Project Details");
            System.out.println("4. Back");
            int c=sc.nextInt(); sc.nextLine();

            if(c==1) viewTasks(name);
            else if(c==2) updateStatus(name);
            else if(c==3) viewProjects();
            else return;
        }
    }

    void viewTasks(String name){
        for(Project p:projects)
            for(Task t:p.tasks)
                if(t.assignee.equalsIgnoreCase(name))
                    System.out.println(t);
    }

    void updateStatus(String name){
        System.out.print("Task ID: "); int tid=sc.nextInt(); sc.nextLine();
        System.out.print("New Status: "); String st=sc.nextLine();
        for(Project p:projects)
            for(Task t:p.tasks)
                if(t.id==tid && t.assignee.equalsIgnoreCase(name))
                    t.status=st;
        System.out.println("Status updated!");
    }

    void viewProjects(){
        for(Project p:projects) System.out.println(p);
    }
}
