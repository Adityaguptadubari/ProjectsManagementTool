import java.util.*;

public class Project {
    public int id;
    public String title;
    public String description;
    public String timeline;
    public List<Task> tasks = new ArrayList<>();

    public Project(int id,String title,String description,String timeline){
        this.id=id; this.title=title; this.description=description; this.timeline=timeline;
    }

    public String toString(){
        return "\nProject ID:"+id+"\nTitle:"+title+"\nDescription:"+description+"\nTimeline:"+timeline+"\n";
    }
}
