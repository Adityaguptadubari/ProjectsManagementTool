import java.util.*;

public class AdminDashboard {
    Scanner sc;
    List<User> users;
    List<Project> projects;

    public AdminDashboard(Scanner sc,List<User> users,List<Project> projects){
        this.sc=sc; this.users=users; this.projects=projects;
    }

    public void menu(){
        while(true){
            System.out.println("\n--- Admin Dashboard ---");
            System.out.println("1. Manage Users");
            System.out.println("2. Manage Projects");
            System.out.println("3. System Settings");
            System.out.println("4. Back");
            System.out.print("Choose: ");
            int c=sc.nextInt(); sc.nextLine();
            if(c==1) manageUsers();
            else if(c==2) manageProjects();
            else if(c==3) System.out.println("System settings updated!");
            else return;
        }
    }

    void manageUsers(){
        while(true){
            System.out.println("\n--- User Management ---");
            System.out.println("1. Add User");
            System.out.println("2. View Users");
            System.out.println("3. Delete User");
            System.out.println("4. Back");
            int c=sc.nextInt(); sc.nextLine();

            if(c==1){
                System.out.print("ID: "); int id=sc.nextInt(); sc.nextLine();
                System.out.print("Name: "); String name=sc.nextLine();
                System.out.print("Email: "); String email=sc.nextLine();
                System.out.print("Role: "); String role=sc.nextLine();
                users.add(new User(id,name,email,role));
                System.out.println("User added!");

            } else if(c==2){
                for(User u:users) System.out.println(u);

            } else if(c==3){
                System.out.print("Enter user ID: ");
                int id=sc.nextInt();
                users.removeIf(u->u.id==id);
                System.out.println("User removed!");

            } else return;
        }
    }

    void manageProjects(){
        while(true){
            System.out.println("\n--- Project Management ---");
            System.out.println("1. View Projects");
            System.out.println("2. Delete Project");
            System.out.println("3. Back");
            int c=sc.nextInt(); sc.nextLine();

            if(c==1){
                for(Project p:projects) System.out.println(p);
            } else if(c==2){
                System.out.print("Enter project ID: ");
                int id=sc.nextInt();
                projects.removeIf(p->p.id==id);
                System.out.println("Project deleted!");
            } else return;
        }
    }
}
